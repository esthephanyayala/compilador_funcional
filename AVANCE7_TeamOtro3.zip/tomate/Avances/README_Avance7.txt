Listas y funciones relacionadas a ellas ya funcionan.
Funciones:
-CDR
-CAR
-APPLY
-LENGHT
-FILTER
-MAP

Documentacion primera version solo parte uno (Descripcion del proyecto)
