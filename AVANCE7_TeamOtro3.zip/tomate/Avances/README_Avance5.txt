Para esta entrega completamos las llamadas de funciones lambda y todo lo relacionado a funciones.
Para el mapa de memoria de ejecucion y la maquina virtual esta en un 50%. Aun no se terminan las expresiones aritmeticas ni los estatutos.
