Para el avance tres se tenia que hacer la generacion de codigo para expresiones aritmeticas, estatutos secuenciales y estatutos de decisiones
Para las expresiones aritmeticas y estatutos de decisiones lo tenemos listo, pero en los estatutos secuenciales no los tenemos todos aun, 
porque algunos de los estatutos que pusimos en nuestro proyecto van orientados a listas, es por eso que estos aun no sabemos como van a funcionar.
