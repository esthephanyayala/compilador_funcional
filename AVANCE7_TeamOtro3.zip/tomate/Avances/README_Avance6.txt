en cuanto a la ejecucion de los estatutos eso ya esta todo al 100
y en cuanto a la creacion de codigo de arreglos vamos en un 50% por que como estamos haciendo una memoria dinamica porque estamos trabajando
con listas y no con arreglos tuvimos que crear esta nueva memoria que actua diferente, y ya tenemos en la vm la ejecucion de algunos de los 
operadores que actuan con listas y con la memoria dinamica, pero nos faltan pocos operadores, filter, map pero seguimos pensando como hacerlos
