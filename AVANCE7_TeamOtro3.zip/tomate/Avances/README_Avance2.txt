Para este avance se tenia que crear la tabla de funciones y variables y ademas el cubo semantico
Para la primera parte esta inconclusa, mas por el hecho que cometimos un error al no tomar en consideracion una 
sugerencia de la profesora en un inicio de no tener variables locales dentro de un ambiente local, por lo cual creamos 
nuestra gramatica que si acepta esto, entonces necesitamos una asesoria para revisar esto mas a fondo.
Para la segunda parte que es el cubo semantico si pudimos avanzar completamente.
