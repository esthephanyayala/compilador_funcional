Conforme a la propuesta que fue aceptada, para el lexico, se realizaron
cambios en los Tokens, para que nuestro programa sea aceptado. 
Para la gramatica se hizo cambio mayormente en la declaracion de variables
para evitar algunas ambiguedades. 

Hasta este punto, nuestro lexer y parser estan terminados. 

